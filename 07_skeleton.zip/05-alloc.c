#include<stdio.h>
#include<stdlib.h>

#define CHAR_MAX_SIZE 100

int main() {

    // alokujte pamet pro prvni retezec
    
    // zkontrolujte, zda se alokace podarila
    
    /// zkopirujte retezec first do dalsiho retezce znak po znaku
        
    // pro druhy retezec alokujte pamet
        
    // oba retezce vypiste
    
    // oba retezce uvolnete z pameti

    return 0;
}
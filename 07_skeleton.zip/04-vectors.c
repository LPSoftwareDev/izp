#include<stdio.h>
#include<stdlib.h>

// datovy typ pro vektor
typedef struct 
{
    
}vector_t;

/// @brief Funkce inicializuje vektor.
/// @param v Vektor
/// @param size Velikost vektoru
/// @return 1 pokud se vse podarilo, 0 jinak
int vector_ctor(vector_t *v, unsigned int size)
{
    
} 

/// @brief  Funkce uvolni vektor z pameti.
/// @param v Vektor
void vector_dtor(vector_t *v)
{
    
}

/// @brief Funkce inicializuje vektor na hodnoty 1,2,3, ... 
/// @param v Vektor
void vector_init(vector_t *v)
{
    
}

/// @brief Funkce vektor vytiskne na obrazovku
/// @param v Vektor
void vector_print(vector_t* v)
{

}

/// @brief Funkce vynasobi vektor konstantou.
/// @param v Vektor
/// @param c Konstanta
void vector_mult(vector_t* v, int c)
{
            
}

/// @brief Funkce pricte k vektoru v1 vektor v2, v1 = v1 + v2
/// @param v1 Vektor
/// @param v2 Vektor
/// @return 0 pokud nelze vektory secist, 1 jinak
int vector_add(vector_t* v1, vector_t* v2)
{

            
}

int main() {

 
}

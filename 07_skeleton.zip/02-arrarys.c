#include<stdio.h>
#include<ctype.h>
#include<string.h>

#define INT_ARRAY_SIZE 5

/**
 * Funkce vytiskne obsah pole o velikosti size na obrazovku
*/
void printIntArray(int array[], int size) 
{
    for (int i = 0; i<size; i++)
    {
        printf("%d ", array[i]);
    }
    printf("\n");
}

/**
 * Funkce vynasobi vsechny prvky pole arr konstantou c.
*/
// void arrMultConst(int* arr, int size, int c)
void arrMultConst(int arr[], int size, int c) 
{
   
}

/**
 * Funkce prevede vsechny znaky v retezci str na velka. 
 * Lze pouzit funkci toupper z knihovny ctype.h
*/
// void changeCase(char* str);
void changeCase(char str[])
{

}

/**
 * Funkce vyhleda podretezec substr v retezci str.
 * Pokud se podretezec ve funkci nachazi, funkce vrati index jeho zacatku.
 * Pokud se retezec ve funkci nenachazi, funkce vrati -1.
*/
int findSubstr(char str[], char substr[]) 
{

}

/**
 * Funkce vlozi do pole arr prvek item na pozici pos.
 * Po vlozeni posune ostatni prvky v poli, posledni prvek z pole odstrani.
*/
void insert(int arr[], int size, int item, int pos) 
{

}



int main() {

    int array[5] = {1,2,3,4,5};
    char str[] = "Hello";
    

    
    return 0;
}